<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:61:"D:\11.23\public/../application/rbac\view\admin\showPower.html";i:1606099435;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <dl>
        <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;if($vo['level']==1): ?>
        <dt><?php echo $vo['power_name']; ?></dt>
        <?php endif; if($vo['level']==2): ?>
        <dd>&emsp;&emsp;<?php echo $vo['power_name']; ?></dd>
        <?php endif; if($vo['level']==3): ?>
        <dd>&emsp;&emsp;&emsp;&emsp;<a href='<?php echo url($vo['power_url']); ?>'><?php echo $vo['power_name']; ?></a></dd>
        <?php endif; endforeach; endif; else: echo "" ;endif; ?>
    </dl>
</body>
</html>