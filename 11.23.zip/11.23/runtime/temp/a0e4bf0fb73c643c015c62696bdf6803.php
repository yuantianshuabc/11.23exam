<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:63:"D:\11.23\public/../application/rbac\view\admin\createPower.html";i:1606097692;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<a href="<?php echo url('loginOut'); ?>">注销</a>
<form action="addPower" method="post">
    权限名称： <input type="text" name="power_name"><br>
    权限url： <input type="text" name="power_url"><br>
    权限等级： <input type="text" name="level"><br>
    权限父级id： <input type="text" name="pids"><br>
    <input type="submit" value="保存">
</form>
</body>
</html>