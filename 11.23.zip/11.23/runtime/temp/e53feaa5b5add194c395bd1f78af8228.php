<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:61:"D:\11.23\public/../application/rbac\view\role\createRole.html";i:1606100733;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form action="<?php echo url('Role/addRole'); ?>" method="post">
    角色名称：<input type="text" name="role_name"><br>
    父级id： <input type="text" name="rids"><br>
    级别： <input type="text" name="level"><br>
    <input type="submit" value="添加">
</form>
</body>
</html>