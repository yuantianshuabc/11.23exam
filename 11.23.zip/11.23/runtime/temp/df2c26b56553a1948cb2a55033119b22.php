<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:60:"D:\11.23\public/../application/rbac\view\admin\showlist.html";i:1606095138;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<a href="<?php echo url('loginOut'); ?>">注销</a>
</body>
</html>