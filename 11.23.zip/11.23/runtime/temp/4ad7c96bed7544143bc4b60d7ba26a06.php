<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:61:"D:\11.23\public/../application/rbac\view\admin\rolepower.html";i:1606101828;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<h1>给角色分配权限</h1>
<form action="addrolepower" method="post">
    角色
    <select name="rid" id="">
        <?php if(is_array($role) || $role instanceof \think\Collection || $role instanceof \think\Paginator): $i = 0; $__LIST__ = $role;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <option value="<?php echo $vo['rid']; ?>"><?php echo $vo['role_name']; ?></option>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </select>
    权限
    <select name="pid" >
        <?php if(is_array($power) || $power instanceof \think\Collection || $power instanceof \think\Paginator): $i = 0; $__LIST__ = $power;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <option value="<?php echo $vo['pid']; ?>"><?php echo $vo['power_name']; ?></option>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </select>
    <input type="submit" value="添加">
</form>
</body>
</html>