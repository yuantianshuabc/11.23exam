<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:61:"D:\11.23\public/../application/rbac\view\admin\adminrole.html";i:1606102339;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<h1>给用户分配角色</h1>
<form action="addadminrole" method="post">
    用户
    <select name="aid" id="">
        <?php if(is_array($admin) || $admin instanceof \think\Collection || $admin instanceof \think\Paginator): $i = 0; $__LIST__ = $admin;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <option value="<?php echo $vo['aid']; ?>"><?php echo $vo['admin_name']; ?></option>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </select>
    角色
    <select name="rid" >
        <?php if(is_array($role) || $role instanceof \think\Collection || $role instanceof \think\Paginator): $i = 0; $__LIST__ = $role;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <option value="<?php echo $vo['rid']; ?>"><?php echo $vo['role_name']; ?></option>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </select>
    <input type="submit" value="添加">
</form>
</body>
</html>