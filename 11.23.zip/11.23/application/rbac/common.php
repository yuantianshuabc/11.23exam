<?php
//无限极分类权限
if (!function_exists("wxj")){
    function wxj($data,$pid=0,$level=1){
        static $arr=[];
        foreach ($data as $v){
            if ($v['pids']==$pid){
                $arr['level']=$level;
                $arr[]=$v;
                wxj($data,$v['pid'],$level+1);
            }
        }
        return $arr;
    }
}
//无限极分类角色
if (!function_exists("role")){
    function role($data,$rid=0,$level=1){
        static $arr=[];
        foreach ($data as $v){
            if ($v['rids']==$rid){
                $arr['level']=$level;
                $arr[]=$v;
                role($data,$v['rid'],$level+1);
            }
        }
        return $arr;
    }
}


