<?php

namespace app\rbac\controller;

use think\Controller;
use think\Request;

class Base extends Controller
{
    public function _initialize()
    {
        $request=Request::instance();
        $url=$request->url();
    }
}
