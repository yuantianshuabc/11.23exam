<?php

namespace app\rbac\controller;

use think\Controller;

class Power extends Controller
{
    public function arr(){
        return "这是个人详情权限";
    }
    public function settime(){
        return "这是定时任务权限";
    }
}
