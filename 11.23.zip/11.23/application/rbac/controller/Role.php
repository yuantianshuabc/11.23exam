<?php

namespace app\rbac\controller;

use think\Controller;

class Role extends Controller
{
    public function showRole(){
        $data=model('Role')->select()->toArray();

        $arr=role($data);

        return view('showRole',['data'=>$arr]);
    }
    public function createRole(){
        return view('createRole');
    }
    public function addRole(){
//        接收数据
        $param=input();
//        验证数据
        $result=$this->validate($param,[
           'role_name|角色名称'=>'require',
        ]);
        if (true !== $result){
            return $this->error($result);
        }
//        入库
        $data=model('Role')->data($param)->allowField(true)->save();
        if ($data){
            return redirect('showRole');
        }
    }
}
