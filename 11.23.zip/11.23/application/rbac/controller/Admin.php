<?php

namespace app\rbac\controller;

use app\admin\model\Power;
use app\common\model\R_p;
use think\Controller;
use think\Session;

class Admin extends Controller
{
//    登录页面
    public function show(){
       return view('');
    }
//    登录
    public function login(){
//        接收数据
        $param=input();
        $name=input('username');
        $password=md5(md5(input('password')));
//        数据验证
        $result=$this->validate($param,[
            'username|用户名'=>'require',
            'password|密码'=>'require'
        ]);
        if (true !== $result){
            return $this->error($result);
        }
//        查询数据
        $data=\app\admin\model\Admin::where('admin_name',$name)->where('admin_password',$password)->find();
        if ($data){
            Session::set('admin',$data);
            return redirect('showlist');
        }else{
            return $this->error('用户名或密码错误');
        }
    }
//    createPwer视图
    public function showlist(){
        return view('createPower');
    }
//    注销
    public function loginOut(){
        Session::get('admin');
        session_destroy();
        return $this->error('注销成功，即将返回登录页面','show');
    }
//    权限添加
   public function addPower(){
//        接收数据
       $param=input();
//       验证
       $result=$this->validate($param,[
           'power_name|权限名称'=>'require',
       ]);
       if (true !== $result){
           return $this->error($result);
       }
       $data=model('Power')->data($param)->allowField(true)->save();
       if ($data){
           return redirect('showPower');
       }else{
           return  $this->error('系统繁忙请稍后再试');
       }
   }
//   权限展示
    public function showPower(){
        $data=\app\common\model\Power::select()->toArray();
        $arr=wxj($data);
       return view('showPower',['data'=>$arr]);
    }
//    给角色分配权限
    public function rolePower(){
        $data=\app\admin\model\Role::select()->toArray();
        $role=role($data);
        $res=\app\common\model\Power::select()->toArray();
        $power=wxj($res);
        return view('rolepower',['role'=>$role,'power'=>$power]);
    }
    public function addrolepower(){
        $param=input();
        $data=model('Rp')->data($param)->allowField(true)->save();
        if ($data){
            return redirect('Role/showRole');
        }
    }
    //    给用户分配角色
    public function adminRole(){
        $data=\app\admin\model\Role::select()->toArray();
        $role=role($data);
        $admin=\app\admin\model\Admin::select();
        return view('adminrole',['role'=>$role,'admin'=>$admin]);
    }
    public function addadminrole(){
        $param=input();

        $data=model('ar')->data($param)->allowField(true)->save();
        if ($data){
            return redirect('Role/showRole');
        }
    }


}
