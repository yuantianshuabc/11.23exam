<?php

namespace app\common\model;

use think\Model;

class Role extends Model
{
    protected $resultSetType='collection';
}
