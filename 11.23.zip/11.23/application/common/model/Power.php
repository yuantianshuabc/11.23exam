<?php

namespace app\common\model;

use think\Model;

class Power extends Model
{
    protected $resultSetType='collection';
}
