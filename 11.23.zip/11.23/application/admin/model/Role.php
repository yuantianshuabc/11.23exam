<?php

namespace app\admin\model;

use think\Model;

class Role extends Model
{
    protected $resultSetType='collection';
}
